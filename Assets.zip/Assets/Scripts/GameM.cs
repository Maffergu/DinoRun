﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
public class GameM : MonoBehaviour
{
    public GameObject panelGO;
    AudioSource sonidolose;
    void Start()
    {
        Time.timeScale = 1;
        panelGO.SetActive(false);
        sonidolose = GetComponent<AudioSource>();
        
    }

    // Update is called once per frame
    public void GameOver()
    {
        Time.timeScale = 0;
        panelGO.SetActive(true);
        sonidolose.Play();
    }

    public void Restart()
    {
        print("Hola");
        SceneManager.LoadScene("SampleScene");
    }

    

    public void backMenu()
    {
        SceneManager.LoadScene("Menu");
    }
}
