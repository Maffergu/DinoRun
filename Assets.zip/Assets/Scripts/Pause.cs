﻿using UnityEngine;
using UnityEngine.UI;
public class Pause : MonoBehaviour
{
    public GameObject pause;
    public bool ispaused;

    void Start()
    {
        pause.SetActive(false);
    }
    private void Update()
    {
        if (Input.GetKeyDown(KeyCode.P))
        {
            if (ispaused)
            {
                resume();
            }
            else
            {
                pausegame();
            }
        }
    }

    public void pausegame()
    {
        pause.SetActive(true);
        Time.timeScale = 0f;
        ispaused = true;
    }

    public void resume()
    {
        pause.SetActive(false);
        Time.timeScale = 1f;
        ispaused = false;
    }
}