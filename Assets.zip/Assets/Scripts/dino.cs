﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class dino : MonoBehaviour
{
    Rigidbody2D rb;
    bool jumping;
    public GameObject stand;
    public GameObject down;
    public GameM gameM;
    AudioSource sonidosalto;
    // Start is called before the first frame update
    void Start()
    {
        
        rb = GetComponent<Rigidbody2D>();
        jumping = false;
        down.SetActive(false);
        sonidosalto = GetComponent<AudioSource>();
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKey("space") && jumping == false)
        {
            rb.velocity = new Vector3(0, 20, 0);
            jumping = true;
            sonidosalto.Play();
        }
        if (Input.GetKey("down") && jumping == false)
        {
            down.SetActive(true);
            stand.SetActive(false);
        }
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        jumping = false;
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if(collision.tag == "obstacle")
        {
            gameM.GameOver();
        }
    }
}
