﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class obstacles : MonoBehaviour
{
    float maxtime;
    float timer;
    public GameObject obs1;
    public GameObject obs2;
    public GameObject obs3;
    public GameObject obs4;
    public GameObject obs5;
    public GameObject obs6;
    public GameObject obs7;
    public GameObject obs8;

    int choseobs;
    // Start is called before the first frame update
    void Start()
    {
        maxtime = 1f;
    }

    // Update is called once per frame
    void Update()
    {
        timer +=Time.deltaTime;
        if(timer >= maxtime)
        {
            Generateobs();
            timer = 0;
        }
    }

    void Generateobs()
    {
        choseobs = Random.Range(1, 9);
        if(choseobs == 1) { GameObject newobs = Instantiate(obs1); }
        if (choseobs == 2) { GameObject newobs = Instantiate(obs2); }
        if (choseobs == 3) { GameObject newobs = Instantiate(obs3); }
        if (choseobs == 4) { GameObject newobs = Instantiate(obs4); }
        if (choseobs == 5) { GameObject newobs = Instantiate(obs5); }
        if (choseobs == 6) { GameObject newobs = Instantiate(obs6); }
        if (choseobs == 7) { GameObject newobs = Instantiate(obs7); }
        if (choseobs == 8) { GameObject newobs = Instantiate(obs8); }

    }
}
