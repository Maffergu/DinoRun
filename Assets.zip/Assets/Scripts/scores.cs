﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class scores : MonoBehaviour
{
    int score;
    public Text HighT;
    Text scoret;
    float timer;
    float maxtime;
    AudioSource sonidocien;

    // Start is called before the first frame update
    void Start()
    {
        HighT.text = "Hi  " + PlayerPrefs.GetInt("HiScore", 0).ToString("00000");
        score = 0;
        scoret = GetComponent<Text>();
        maxtime = 0.1f;
        sonidocien = GetComponent<AudioSource>();

    }

    // Update is called once per frame
    void Update()
    {
        timer += Time.deltaTime;
        if(timer >= maxtime)
        {
            score++;
            scoret.text = score.ToString("00000");
            timer = 0;
            if(score % 100 == 0)
            {
                sonidocien.Play();
                Time.timeScale += 0.1f;
            }
        }
        if(Time.timeScale == 0)
        {
            if(score > PlayerPrefs.GetInt("HiScore", 0))
            {
                PlayerPrefs.SetInt("HiScore", score);
                HighT.text = "Hi  " + PlayerPrefs.GetInt("HiScore", 0).ToString("00000");

            }
        }
    }
}
